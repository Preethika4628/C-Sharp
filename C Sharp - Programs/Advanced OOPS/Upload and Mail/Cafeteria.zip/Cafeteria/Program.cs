﻿using System;
namespace Cafeteria;
class Program 
{
    public static void Main(string[] args)
    {
        Console.WriteLine("*****CAFETERIA CARD MANAGEMENT*****");
        Operation.AddDefaultData();
        Operation.MainMenu();
    }
}