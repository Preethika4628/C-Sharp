using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class FileHandling
    {
        public static void Create()
        {
            if(!Directory.Exists("Cafeteria"))
            {
                Console.WriteLine("Creating Folder");
                Directory.CreateDirectory("Cafeteria");
            }
            //files for user details
            if(!File.Exists("Cafeteria/UserDetails.csv"))
            {
                Console.WriteLine("Creating file..");
                File.Create("Cafeteria/UserDetails.csv").Close();
            }
            //file for food details
            if(!File.Exists("Cafeteria/FoodDetails.csv"))
            {
                Console.WriteLine("Creating file..");
                File.Create("Cafeteria/FoodDetails.csv").Close();
            }
            //file for cart details
            if(!File.Exists("Cafeteria/CartItems.csv"))
            {
                Console.WriteLine("Creating file..");
                File.Create("Cafeteria/CartItems.csv").Close();
            }
            //file for order details
            if(!File.Exists("Cafeteria/OrderDetails.csv"))
            {
                Console.WriteLine("Creating file..");
                File.Create("Cafeteria/OrderDetails.csv").Close();
            }
        }
        public static void WriteToCSV()
        {
            //user details
            string[] students = new string[Operation.userList.Count];
            for(int i=0; i<Operation.userList.Count; i++)
            {
                students[i] = Operation.userList[i].UserID + "," + Operation.userList[i].Name + "," + Operation.userList[i].FatherName + "," + Operation.userList[i].WorkStationNumber + "," + Operation.userList[i].WalletBalance ;
            }
            File.WriteAllLines("SyncfusionAdmission/StudentDetails.csv", students);

            //food details
            string[] department = new string[Operation.foodList.Count];
            for(int i=0; i<Operation.foodList.Count; i++)
            {
                department[i] = Operation.foodList[i].FoodID + "," + Operation.foodList[i].FoodName + "," +Operation.foodList[i].Price;
            }
            File.WriteAllLines("SyncfusionAdmission/DepartmentDetails.csv", department);

            //cart items details
            string[] cart = new string[Operation.cartList.Count];
            for(int i=0; i<Operation.cartList.Count; i++)
            {
                cart[i] = Operation.cartList[i].ItemID + "," + Operation.cartList[i].OrderID + "," + Operation.cartList[i].FoodID + "," + Operation.cartList[i].OrderQuantity;
            }
            File.WriteAllLines("SyncfusionAdmission/AdmissionDetails.csv", cart);

            //order details
            string[] order = new string[Operation.orderList.Count];
            for(int i=0; i<Operation.orderList.Count; i++)
            {
                department[i] = Operation.orderList[i].OrderID + "," + Operation.orderList[i].UserID + "," +Operation.orderList[i].OrderStatus;
            }
            File.WriteAllLines("SyncfusionAdmission/DepartmentDetails.csv", department);
        }
    }
}